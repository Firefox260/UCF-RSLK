var indexSectionsWithContent =
{
  0: "bcdegilmopqrsw",
  1: "bcgqr",
  2: "eqrs",
  3: "bcdegiprsw",
  4: "cimq",
  5: "q",
  6: "mo",
  7: "bdelmqrsw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Macros"
};

