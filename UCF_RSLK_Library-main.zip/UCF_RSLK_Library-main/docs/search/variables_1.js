var searchData=
[
  ['initialized_201',['initialized',['../struct_q_t_r_sensors_1_1_calibration_data.html#ab781ae5ef2d5a091c03297da9c167b9d',1,'QTRSensors::CalibrationData']]]
];
